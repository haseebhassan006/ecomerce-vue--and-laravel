

<p align="center">
<a href="https:lacommerz.limmexbd.com">Limmerz</a><br>
<a href="https://limmexbd.com">Product Of Limmex Automation</a><br>
<a href="https://facebook.com/snsabbir.fci">Developer Shakhawat</a>
<a href="https://github.com/arifuzzaman31">Developer Arifuzzaman</a>

</p>

## About Limmerz

Limmerz is Laravel and vue js based ecommerce solution for both grocery and lifestyle.

Licence under  <a href="https://limmexbd.com">limmex automaion</a> 